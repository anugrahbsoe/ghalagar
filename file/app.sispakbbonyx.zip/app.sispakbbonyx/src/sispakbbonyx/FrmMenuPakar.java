/*
 ======================================================================= 
 * Nama program : 
 * Keterangan	: Memuat Menu Pakar
 * Nama Fie		: FrmMenuPakar.java
 ======================================================================= 
 */
package sispakbbonyx;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Color;

import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.SwingConstants;
import javax.swing.ImageIcon;

import IconMakeOver.IconLabel;
import IconMakeOver.IconBayang;

import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JRadioButton;

import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class FrmMenuPakar extends JFrame {

	private JPanel contentPane;
	private JPanel panel;
	private JLabel lblSistemPakarDiagnosa;
	private JLabel label_1;
	private JLabel lblAnugrah;
	private JPanel panel_1;
	private IconLabel lblDiagnosa;
	private IconLabel lblBantuan;
	private IconLabel lblLogout;
	private JLabel lblpengaturan;
	private IconLabel cnlblPengaturan;
	private JLabel lblBlackberryOnyx;
	private JLabel lblBerbasisClientserver;
	private JPanel panel_2;

	/**
	 * Launch the application.
	 */
	
	 /*public static void main(String[] args) { EventQueue.invokeLater(new
	 Runnable() { public void run() { try { FrmMenuPakar frame = new
	 FrmMenuPakar(); frame.setVisible(true); } catch (Exception e) {
	 e.printStackTrace(); } } }); }*/
	 

	/**
	 * Create the frame.
	 */
	public FrmMenuPakar() {
		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage(FrmMenuPakar.class.getResource("/image/konversation.png")));
		// setIconImage(Toolkit.getDefaultToolkit().getImage("/home/anugrahbsoe/workspace/SistemPakarBB/src/image/bb.png"));
		// setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 755, 456);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 102, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setLocationRelativeTo(null);
		setContentPane(contentPane);
		contentPane.setLayout(null);

		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(0, 0, 0));
		panel.setBounds(0, -11, 753, 116);
		contentPane.add(panel);

		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(FrmMenuPakar.class.getResource("/image/logo-kecil.png")));
		label.setBounds(30, 0, 110, 128);
		panel.add(label);

		label_1 = new JLabel("Selamat Datang di");
		label_1.setForeground(Color.WHITE);
		label_1.setFont(new Font("DejaVu Sans Condensed", Font.BOLD, 10));
		label_1.setBounds(152, 12, 295, 32);
		panel.add(label_1);

		lblSistemPakarDiagnosa = new JLabel(
				"Sistem Pakar untuk Mengidentifikasi Kerusakan");
		lblSistemPakarDiagnosa.setForeground(Color.WHITE);
		lblSistemPakarDiagnosa.setFont(new Font("DejaVu Sans Condensed",
				Font.BOLD, 15));
		lblSistemPakarDiagnosa.setBounds(152, 41, 472, 18);
		panel.add(lblSistemPakarDiagnosa);
		
		lblBlackberryOnyx = new JLabel("Blackberry Onyx 1 dengan Metode Backward Chaining");
		lblBlackberryOnyx.setForeground(Color.WHITE);
		lblBlackberryOnyx.setFont(new Font("DejaVu Sans Condensed", Font.BOLD, 15));
		lblBlackberryOnyx.setBounds(152, 62, 542, 18);
		panel.add(lblBlackberryOnyx);
		
		lblBerbasisClientserver = new JLabel("Berbasis Client-Server");
		lblBerbasisClientserver.setForeground(Color.WHITE);
		lblBerbasisClientserver.setFont(new Font("DejaVu Sans Condensed", Font.BOLD, 15));
		lblBerbasisClientserver.setBounds(152, 86, 458, 18);
		panel.add(lblBerbasisClientserver);

		panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBackground(Color.BLACK);
		panel_1.setBounds(0, 397, 753, 27);
		contentPane.add(panel_1);

		lblAnugrah = new JLabel("1411530169 - Ghalagghar Zakario Zalfano");
		lblAnugrah.setBounds(0, 0, 760, 27);
		panel_1.add(lblAnugrah);
		lblAnugrah.setHorizontalTextPosition(SwingConstants.LEADING);
		lblAnugrah.setHorizontalAlignment(SwingConstants.CENTER);
		lblAnugrah.setForeground(Color.WHITE);
		lblAnugrah.setFont(new Font("DejaVu Sans Condensed", Font.BOLD, 10));

		lblDiagnosa = new IconLabel();
		lblDiagnosa.setForeground(new Color(255, 255, 255));
		lblDiagnosa.setIconReflect(new ImageIcon(FrmMenuPakar.class.getResource("/image/search.png")));
		lblDiagnosa.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new FrmPilihKerusakan().show();
			}
		});
		lblDiagnosa.setText("Diagnosa");
		lblDiagnosa.setBounds(42, 161, 100, 202);
		contentPane.add(lblDiagnosa);

		lblBantuan = new IconLabel();
		lblBantuan.setForeground(new Color(255, 255, 255));
		lblBantuan.setIconReflect(new ImageIcon(FrmMenuPakar.class.getResource("/image/dialog-question.png")));
		lblBantuan.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				FrmBantuan bantuan = new FrmBantuan();
				bantuan.setVisible(true);
			}
		});
		lblBantuan.setText("Bantuan");
		lblBantuan.setBounds(469, 166, 106, 197);
		contentPane.add(lblBantuan);

		lblLogout = new IconLabel();
		lblLogout.setForeground(new Color(255, 255, 255));
		lblLogout.setIconReflect(new ImageIcon(FrmMenuPakar.class.getResource("/image/chrome-eoieeedlomnegifmaghhjnghhmcldobl-Default.png")));
		lblLogout.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Keluar();
				//new Homescreen().show();
				//dispose();
			}
		});
		lblLogout.setText("Logout");
		lblLogout.setBounds(621, 161, 100, 202);
		contentPane.add(lblLogout);

		lblpengaturan = new JLabel("--MENU PAKAR--");
		lblpengaturan.setBackground(new Color(0, 204, 255));
		lblpengaturan.setForeground(new Color(255, 255, 255));
		lblpengaturan.setHorizontalAlignment(SwingConstants.CENTER);
		lblpengaturan.setFont(new Font("Dialog", Font.BOLD, 16));
		lblpengaturan.setHorizontalTextPosition(SwingConstants.CENTER);
		lblpengaturan.setBounds(252, 128, 224, 15);
		contentPane.add(lblpengaturan);

		IconLabel cnlblMasterPengetahuan = new IconLabel();
		cnlblMasterPengetahuan.setForeground(new Color(255, 255, 255));
		cnlblMasterPengetahuan.setIconReflect(new ImageIcon(FrmMenuPakar.class.getResource("/image/gajim.png")));
		cnlblMasterPengetahuan.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				FrmPengetahuan pengetahuan = new FrmPengetahuan();
				pengetahuan.show();
			}
		});
		cnlblMasterPengetahuan.setText("Pengetahuan");
		cnlblMasterPengetahuan.setBounds(179, 161, 100, 202);
		contentPane.add(cnlblMasterPengetahuan);

		IconLabel cnlblMasterSolusi = new IconLabel();
		cnlblMasterSolusi.setForeground(new Color(255, 255, 255));
		cnlblMasterSolusi.setIconReflect(new ImageIcon(FrmMenuPakar.class.getResource("/image/alacarte.png")));
		cnlblMasterSolusi.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				FrmKamusPakar kamus = new FrmKamusPakar();
				kamus.show();
			}
		});
		cnlblMasterSolusi.setText("Kamus");
		cnlblMasterSolusi.setBounds(324, 161, 106, 202);
		contentPane.add(cnlblMasterSolusi);
		
		panel_2 = new JPanel();
		panel_2.setBackground(new Color(255, 255, 255));
		panel_2.setBounds(0, 102, 753, 10);
		contentPane.add(panel_2);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(new Color(255, 255, 255));
		panel_3.setBounds(0, 390, 753, 10);
		contentPane.add(panel_3);

		/*cnlblPengaturan = new IconLabel();
		cnlblPengaturan.setVisible(false);
		cnlblPengaturan.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new FrmPengaturan().show();
			}
		});
		cnlblPengaturan.setIcon(new ImageIcon(FrmMenuPakar.class
				.getResource("/image/setting.png")));
		cnlblPengaturan.setText("Pengaturan");
		cnlblPengaturan.setBounds(376, 161, 100, 129);
		contentPane.add(cnlblPengaturan);*/

	} // akhir konstruktor
	
	void Keluar() {
		try {
			int reply = JOptionPane.showConfirmDialog(this,
					"Yakin Mau Keluar?", "Sistem - Keluar",
					JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
			if (reply == JOptionPane.YES_OPTION) {
				new Homescreen().show();
				setVisible(false); // Menyembunyikan Frame.
				dispose(); // Membersihkan Resource dari system memori
				setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Membebaskan
																// aplikasi dari
																// memori
				// System.exit (0); //Keluar dari Aplikasi.
			}
		} catch (Exception ex) {
		}
	}
}
