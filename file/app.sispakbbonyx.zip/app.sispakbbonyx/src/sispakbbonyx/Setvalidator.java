/*
 ======================================================================= 
 * Nama program : 
 * Keterangan	: Memuat Validasi
 * Nama Fie		: SetValidasi.java
 ======================================================================= 
 */
package sispakbbonyx;

import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;

public class Setvalidator extends PlainDocument {
	private int maxCharacter;
	private boolean angkaOnly;
	private String angkaChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

	public Setvalidator() {
		this(-1, false);
	}

	public Setvalidator(int maxCharacter, boolean angkaOnly) {
		this.maxCharacter = maxCharacter;
		this.angkaOnly = angkaOnly;
	}

	@Override
	public void insertString(int offs, String str, AttributeSet a)
			throws BadLocationException {
		if (angkaOnly) {
			if (maxCharacter == -1) {
				if (checkString(str)) {
					super.insertString(offs, str, a);
				}
			} else {
				int panjangTextLama = getLength();
				int panjangTextBaru = str.length();
				if ((panjangTextLama + panjangTextBaru) <= maxCharacter) {
					if (checkString(str)) {
						super.insertString(offs, str, a);
					}
				}
			}
		} else {
			if (maxCharacter == -1) {
				super.insertString(offs, str, a);
			} else {
				int panjangTextLama = getLength();
				int panjangTextBaru = str.length();
				if ((panjangTextLama + panjangTextBaru) <= maxCharacter) {
					super.insertString(offs, str, a);
				}
			}
		}
	}

	private boolean checkString(String input) {
		boolean result = false;
		for (int i = 0; i < input.length(); i++) {
			if (angkaChars.indexOf(input.charAt(i)) == -1) {
				result = false;
				break;
			} else {
				result = true;
			}
		}
		return result;
	}
}
