/*
 ======================================================================= 
 * Nama program : 
 * Keterangan	: Memuat Kerusakan
 * Nama Fie		: FrmKerusakan.java
 ======================================================================= 
 */
package sispakbbonyx;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

import java.awt.Color;

import javax.swing.JLabel;

import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JTable;

import com.mysql.jdbc.PreparedStatement;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JTextArea;
import javax.swing.SwingConstants;

import net.java.balloontip.BalloonTip;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import java.awt.Toolkit;

public class FrmKerusakan extends JFrame {

	private JPanel contentPane;
	private JLabel lblIdKerusakan;
	private JLabel lblNmkerusakan;
	private JTextField txtIdKerusakan;
	private JButton btnKeluar;
	private JButton btnHapus;
	private JButton btnUbah;
	private JButton btnTambah;
	private JTable table;
	DefaultTableModel tabelModel;
	String data[] = { "Id_Kerusakan", "NmKerusakan", "Solusi" };
	private JTextArea txaNmKerusakan;
	private JTextArea txaSolusi;
	private JLabel lblMasterKerusakan;
	private JTextField txtCari;
	private JLabel lblCari;
	private JButton btnCari;
	private JScrollPane scrSolusi;
	private final JPanel panel_1 = new JPanel();
	private JLabel label;

	/**
	 * Launch the application.
	 */
	
	  /*public static void main(String[] args) { EventQueue.invokeLater(new
	  Runnable() { public void run() { try { FrmKerusakan frame = new
	  FrmKerusakan(); frame.setVisible(true); } catch (Exception e) {
	  e.printStackTrace(); } } }); }*/
	 

	/**
	 * Create the frame.
	 */
	public FrmKerusakan() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(FrmKerusakan.class.getResource("/image/konversation.png")));
		setResizable(false);
		// setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 525, 435);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(0, 102, 255));
		panel.setBounds(0, -14, 523, 77);
		contentPane.add(panel);

		lblMasterKerusakan = new JLabel("Master Kerusakan");
		lblMasterKerusakan.setHorizontalAlignment(SwingConstants.CENTER);
		lblMasterKerusakan.setForeground(Color.WHITE);
		lblMasterKerusakan.setFont(new Font("DejaVu Sans Condensed", Font.BOLD,
				15));
		lblMasterKerusakan.setBounds(138, 30, 276, 29);
		panel.add(lblMasterKerusakan);
		
		label = new JLabel("");
		label.setIcon(new ImageIcon(FrmKerusakan.class.getResource("/image/activity-log-manager.png")));
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setForeground(Color.WHITE);
		label.setFont(new Font("DejaVu Sans Condensed", Font.BOLD, 15));
		label.setBounds(-13, 12, 91, 47);
		panel.add(label);

		lblIdKerusakan = new JLabel("Id Kerusakan :");
		lblIdKerusakan.setBounds(24, 104, 126, 15);
		contentPane.add(lblIdKerusakan);

		lblNmkerusakan = new JLabel("Nama Kerusakan :");
		lblNmkerusakan.setBounds(24, 131, 145, 15);
		contentPane.add(lblNmkerusakan);

		txtIdKerusakan = new JTextField();
		txtIdKerusakan.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				e.setKeyChar(Character.toUpperCase(e.getKeyChar()));
			}
		});
		txtIdKerusakan.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				BalloonTip diagnosa = new BalloonTip(txtIdKerusakan, "IdKerusakan memuat huruf dan angka dan berjumlah 4 digit. Ex : K010");
			}
		});
		txtIdKerusakan.setBounds(170, 104, 114, 19);
		txtIdKerusakan.setDocument(new Setvalidator(4, true));
		contentPane.add(txtIdKerusakan);
		txtIdKerusakan.setColumns(10);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBackground(Color.WHITE);
		scrollPane.setBounds(24, 202, 479, 123);
		contentPane.add(scrollPane);

		tabelModel = new DefaultTableModel(null, data);
		table = new JTable();
		table.setBackground(Color.WHITE);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent me) {
				int pilih = table.getSelectedRow();
				if (pilih < 0) {
					return;
				}

				String idkesimpulan = (String) tabelModel.getValueAt(pilih, 0);
				txtIdKerusakan.setText(idkesimpulan);
				String kesimpulan = (String) tabelModel.getValueAt(pilih, 1);
				txaNmKerusakan.setText(kesimpulan);
				String solusi = (String) tabelModel.getValueAt(pilih, 2);
				txaSolusi.setText(solusi);
				btnUbah.setEnabled(true);
				btnHapus.setEnabled(true);
				btnTambah.setEnabled(false);
				btnKeluar.setEnabled(false);
			}
		});
		table.setModel(tabelModel);
		scrollPane.setViewportView(table);

		btnTambah = new JButton("Tambah");
		btnTambah.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(txtIdKerusakan.getText().length() > 4){
					JOptionPane.showMessageDialog(null,"IdGejala yang di input lebih dari 4 digit","Ingat",JOptionPane.INFORMATION_MESSAGE);
					txtIdKerusakan.setText("");
					txtIdKerusakan.requestFocus();
						}
				else if(txtIdKerusakan.getText().length() < 4){
					JOptionPane.showMessageDialog(null,"IdGejala yang di input kurang dari 4 digit","Ingat",JOptionPane.INFORMATION_MESSAGE);
					txtIdKerusakan.setText("");
						}
				else if(txtIdKerusakan.getText().isEmpty()){
					JOptionPane.showMessageDialog(null,"IdKerusakan tidak boleh kosong","Perhatian!", JOptionPane.WARNING_MESSAGE);
					txtIdKerusakan.requestFocus();
				}else if(txaNmKerusakan.getText().isEmpty()){
					JOptionPane.showMessageDialog(null,"NamaKerusakan tidak boleh kosong","Perhatian!", JOptionPane.WARNING_MESSAGE);
					txaNmKerusakan.requestFocus();
					}else if(txaSolusi.getText().isEmpty()){
						JOptionPane.showMessageDialog(null,"Solusi tidak boleh kosong","Perhatian!", JOptionPane.WARNING_MESSAGE);
						txaSolusi.requestFocus();
						}
				else{
				try {
					Connection con = (Connection) Koneksi.getKoneksi();
					String query = "INSERT INTO Kerusakan VALUES(?,?,?)";
					PreparedStatement prepare = (PreparedStatement) con
							.prepareStatement(query);

					prepare.setString(1, txtIdKerusakan.getText());
					prepare.setString(2, txaNmKerusakan.getText());
					prepare.setString(3, txaSolusi.getText());
					prepare.executeUpdate();
					JOptionPane.showMessageDialog(null,
							"Data berhasil ditambah", "Pesan",
							JOptionPane.INFORMATION_MESSAGE);
					prepare.close();
					tampilTabel();
					bersih();
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, "Data gagal ditambah",
							"Pesan", JOptionPane.ERROR_MESSAGE);
					System.out.println(ex);
					}
				}
			}
		});
		btnTambah.setForeground(Color.WHITE);
		btnTambah.setBackground(new Color(0, 102, 255));
		btnTambah.setBounds(34, 369, 96, 25);
		contentPane.add(btnTambah);

		btnUbah = new JButton("Ubah");
		btnUbah.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Connection con = (Connection) Koneksi.getKoneksi();
					String query = "UPDATE Kerusakan SET NmKerusakan  = ?, Solusi  = ? WHERE IdKerusakan = ? ";
					PreparedStatement prepare = (PreparedStatement) con
							.prepareStatement(query);
					prepare.setString(1, txaNmKerusakan.getText());
					prepare.setString(2, txaSolusi.getText());
					prepare.setString(3, txtIdKerusakan.getText());
					prepare.executeUpdate();
					JOptionPane.showMessageDialog(null, "Data berhasil diubah",
							"Pesan", JOptionPane.INFORMATION_MESSAGE);
					prepare.close();
					bersih();
					tampilTabel();
					btnTambah.setEnabled(true);
					btnKeluar.setEnabled(true);
					btnUbah.setEnabled(false);
					btnHapus.setEnabled(false);
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, "Data gagal diubah",
							"Pesan", JOptionPane.ERROR_MESSAGE);
					System.out.println(ex);
				}
			}
		});
		btnUbah.setForeground(Color.WHITE);
		btnUbah.setBackground(new Color(0, 102, 255));
		btnUbah.setEnabled(false);
		btnUbah.setBounds(126, 369, 96, 25);
		contentPane.add(btnUbah);

		btnHapus = new JButton("Hapus");
		btnHapus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Connection con = (Connection) Koneksi.getKoneksi();
					String query = "DELETE FROM Kerusakan WHERE IdKerusakan = ?";
					PreparedStatement prepare = (PreparedStatement) con
							.prepareStatement(query);

					prepare.setString(1, txtIdKerusakan.getText());
					prepare.executeUpdate();
					JOptionPane.showMessageDialog(null,
							"Data berhasil dihapus", "Pesan",
							JOptionPane.INFORMATION_MESSAGE);
					prepare.close();
					tampilTabel();
					bersih();
					btnTambah.setEnabled(true);
					btnKeluar.setEnabled(true);
					btnUbah.setEnabled(false);
					btnHapus.setEnabled(false);
				} catch (Exception ex) {
					System.out.println(ex);
					JOptionPane.showMessageDialog(null, "Data gagal diupdate",
							"Pesan", JOptionPane.INFORMATION_MESSAGE);
				}
			}
		});
		btnHapus.setForeground(Color.WHITE);
		btnHapus.setBackground(new Color(0, 102, 255));
		btnHapus.setEnabled(false);
		btnHapus.setBounds(218, 369, 96, 25);
		contentPane.add(btnHapus);

		btnKeluar = new JButton("Keluar");
		btnKeluar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Keluar();
			}
		});
		btnKeluar.setForeground(Color.WHITE);
		btnKeluar.setBackground(new Color(0, 102, 255));
		btnKeluar.setBounds(396, 369, 96, 25);
		contentPane.add(btnKeluar);

		JScrollPane scrPertanyaan = new JScrollPane();
		scrPertanyaan.setBounds(168, 130, 335, 25);
		contentPane.add(scrPertanyaan);

		txaNmKerusakan = new JTextArea();
		scrPertanyaan.setViewportView(txaNmKerusakan);
		txaNmKerusakan.setDocument(new Setvalidator(250, true));

		JLabel lblSolusi = new JLabel("Solusi :");
		lblSolusi.setBounds(24, 158, 104, 15);
		contentPane.add(lblSolusi);

		scrSolusi = new JScrollPane();
		scrSolusi.setBounds(170, 165, 335, 25);
		contentPane.add(scrSolusi);

		txaSolusi = new JTextArea();
		scrSolusi.setViewportView(txaSolusi);
		txaSolusi.setDocument(new Setvalidator(1000, true));
		
		btnCari = new JButton("");
		btnCari.setIcon(new ImageIcon(FrmKerusakan.class.getResource("/image/system-search.png")));
		btnCari.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cariKerusakan();
			}
		});
		btnCari.setForeground(Color.WHITE);
		btnCari.setBackground(Color.BLACK);
		btnCari.setBounds(455, 334, 29, 23);
		contentPane.add(btnCari);
		
		txtCari = new JTextField();
		txtCari.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cariKerusakan();
			}
		});
		txtCari.setColumns(10);
		txtCari.setBounds(159, 337, 289, 19);
		contentPane.add(txtCari);
		
		lblCari = new JLabel("Cari Kerusakan :");
		lblCari.setBounds(34, 337, 126, 15);
		contentPane.add(lblCari);
		panel_1.setBackground(new Color(0, 0, 0));
		panel_1.setBounds(0, 63, 523, 10);
		contentPane.add(panel_1);
		setLocationRelativeTo(null);

		tampilTabel();
	}

	void cariKerusakan(){
		try{
			Connection con = (Connection) Koneksi.getKoneksi();
			Statement state = con.createStatement();
			String sql = "select * from Kerusakan where IdKerusakan like '%" + txtCari.getText()+ "%'" +
					"or NmKerusakan like '%" + txtCari.getText() + "%'";
			ResultSet rs = state.executeQuery(sql);
			while (rs.next()) {
			tabelModel.addRow(new Object[]{
			rs.getString(1),
			rs.getString(2),
			rs.getString(3)
			});
			}
			table.setModel(tabelModel);
			//tampilTabel();
			txtCari.setText("");
			}catch (Exception e){
				System.out.println(e);
			}
			}
	
	public void tampilTabel() {
		try {
			hapusIsiTabel();
			Connection con = (Connection) Koneksi.getKoneksi();
			Statement state = con.createStatement();
			String query = "SELECT * FROM Kerusakan";
			ResultSet rs = state.executeQuery(query);
			while (rs.next()) {

				Object obj[] = new Object[3];
				obj[0] = rs.getString(1);
				obj[1] = rs.getString(2);
				obj[2] = rs.getString(3);
				tabelModel.addRow(obj);
				sesuaikanKolom();
			}
			rs.close();
			state.close();
		} catch (Exception ex) {
			System.out.println(ex);
		}
	}

	void sesuaikanKolom() {
		// cara untuk menyesuaikan kolom dari tabel adalah mengambil
		// lebar kolom yang ada kemudian sesuaikan
		TableColumnModel modelKolom = table.getColumnModel();

		for (int kol = 0; kol < modelKolom.getColumnCount(); kol++) {
			int lebarKolomMax = 0;
			for (int baris = 0; baris < table.getRowCount(); baris++) {
				TableCellRenderer rend = table.getCellRenderer(baris, kol);
				Object nilaiTablel = table.getValueAt(baris, kol);
				Component comp = rend.getTableCellRendererComponent(table,
						nilaiTablel, false, false, baris, kol);
				lebarKolomMax = Math.max(comp.getPreferredSize().width,
						lebarKolomMax);
			}// akhir for baris
			TableColumn kolom = modelKolom.getColumn(kol);
			kolom.setPreferredWidth(lebarKolomMax);
		}// akhir for kolom
	}

	public void hapusIsiTabel() {
		int a = table.getRowCount();
		int brs;

		for (brs = 0; brs < a; brs++) {
			tabelModel.removeRow(0);
		}
	}

	void Keluar() {
		try {
			int reply = JOptionPane.showConfirmDialog(this,
					"Yakin Mau Keluar?", "Sistem - Keluar",
					JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
			if (reply == JOptionPane.YES_OPTION) {
				setVisible(false); // Menyembunyikan Frame.
				dispose(); // Membersihkan Resource dari system memori
				setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Membebaskan
																// aplikasi dari
																// memori
				// System.exit (0); //Keluar dari Aplikasi.
			}
		} catch (Exception ex) {
		}
	}
	
	void bersih(){
			txtIdKerusakan.setText("");
			txaNmKerusakan.setText("");
			txaSolusi.setText("");
		}
}