/*
 ======================================================================= 
 * Nama program : 
 * Keterangan	: Memuat Target
 * Nama Fie		: FrmTarget.java
 ======================================================================= 
 */
package sispakbbonyx;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

import java.awt.Color;

import javax.swing.JLabel;

import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JTable;

import com.mysql.jdbc.PreparedStatement;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JTextArea;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import java.awt.Toolkit;

public class FrmTarget extends JFrame {

	private JPanel contentPane;
	private JLabel lblKerusakan;
	private JButton btnKeluar;
	private JButton btnTambah;
	private JTable table;
	DefaultTableModel tabelModel;
	String data[] = { "IdArahan", "IdKerusakan", "IdGejala" };
	private JLabel lblIdGejala;
	private JTextField txtNmGejala;
	private JTextField txtNmKerusakan;
	private JLabel lblNmGejala;
	private JLabel lblNamaKerusakan;
	private JComboBox cmbIdGejala;
	private JComboBox cmbIdKerusakan;
	private JLabel lblIdTarget;
	private JTextField txtIdTarget;
	private JButton btnUbah;
	private JButton btnHapus;
	private JButton btnCari;
	private JTextField txtCari;
	private JLabel lblArahan;
	private JLabel lbltarget;
	private final JPanel panel_1 = new JPanel();
	private JLabel label;

	/**
	 * Launch the application.
	 */
	
	 /*public static void main(String[] args) { EventQueue.invokeLater(new
	 Runnable() { public void run() { try { FrmTarget frame = new
	 FrmTarget(); frame.setVisible(true); } catch (Exception e) {
	 e.printStackTrace(); } } }); }*/
	 

	/**
	 * Create the frame.
	 */
	public FrmTarget() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(FrmTarget.class.getResource("/image/konversation.png")));
		setResizable(false);
		// setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 560, 471);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(0, 102, 255));
		panel.setBounds(0, -14, 558, 72);
		contentPane.add(panel);

		lbltarget = new JLabel("Target");
		lbltarget.setForeground(Color.WHITE);
		lbltarget
				.setFont(new Font("DejaVu Sans Condensed", Font.BOLD, 15));
		lbltarget.setBounds(233, 30, 66, 29);
		panel.add(lbltarget);
		
		label = new JLabel("");
		label.setIcon(new ImageIcon(FrmTarget.class.getResource("/image/preferences-system.png")));
		label.setForeground(Color.WHITE);
		label.setFont(new Font("DejaVu Sans Condensed", Font.BOLD, 15));
		label.setBounds(-22, 12, 66, 60);
		panel.add(label);

		lblKerusakan = new JLabel("Id Kerusakan :");
		lblKerusakan.setBounds(24, 128, 126, 15);
		contentPane.add(lblKerusakan);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBackground(Color.WHITE);
		scrollPane.setBounds(24, 189, 515, 161);
		contentPane.add(scrollPane);

		tabelModel = new DefaultTableModel(null, data);
		table = new JTable();
		table.setBackground(Color.WHITE);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent me) {
				int pilih = table.getSelectedRow();
				if (pilih < 0) {
					return;
				}

				String idarahan = (String) tabelModel.getValueAt(pilih, 0);
				txtIdTarget.setText(idarahan);
				String idkerusakan = (String) tabelModel.getValueAt(pilih, 1);
				cmbIdKerusakan.setSelectedItem(idkerusakan);
				String idgejala = (String) tabelModel.getValueAt(pilih, 2);
				cmbIdGejala.setSelectedItem(idgejala);
				btnUbah.setEnabled(true);
				btnHapus.setEnabled(true);
				btnTambah.setEnabled(false);
				btnKeluar.setEnabled(false);
			}
		});
		table.setModel(tabelModel);
		scrollPane.setViewportView(table);

		btnTambah = new JButton("Tambah");
		btnTambah.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (cmbIdKerusakan.getSelectedIndex() == 0) {
					JOptionPane.showMessageDialog(null,
							"Pilih salah satu kerusakan", "Pesan",
							JOptionPane.INFORMATION_MESSAGE);
				}else if(cmbIdGejala.getSelectedIndex() == 0) {
					JOptionPane.showMessageDialog(null,
							"Pilih salah satu gejala", "Pesan",
							JOptionPane.INFORMATION_MESSAGE);
					
				}
				else{
				try {
					//Connection konek = (Connection) Koneksi.getKoneksi();
					Class.forName("com.mysql.jdbc.Driver").newInstance();
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost/sispakonyx",
					"root","root");
					//Connection con=DriverManager.getConnection("jdbc:mysql://192.168.1.123/sistempakar",
						//	"root","root");
					String query = "INSERT INTO Target VALUES(?,?,?)";
					PreparedStatement prepare = (PreparedStatement) con
							.prepareStatement(query);
					prepare.setString(1, txtIdTarget.getText());
					prepare.setString(2,
							(String) cmbIdKerusakan.getSelectedItem());
					prepare.setString(3, (String) cmbIdGejala.getSelectedItem());
					// prepare.setString(1,txtIdArahan.getText());
					prepare.executeUpdate();
					JOptionPane.showMessageDialog(null,
							"Data berhasil ditambah", "Pesan",
							JOptionPane.INFORMATION_MESSAGE);
					prepare.close();
					tampilTabel();
					autoNomer("Target", "TG", JFrame.EXIT_ON_CLOSE);
					clean();
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, "Data gagal ditambah",
							"Pesan", JOptionPane.ERROR_MESSAGE);
					System.out.println(ex);
				}
				}
			}
		});
		btnTambah.setForeground(Color.WHITE);
		btnTambah.setBackground(new Color(0, 102, 255));
		btnTambah.setBounds(24, 402, 96, 25);
		contentPane.add(btnTambah);

		btnKeluar = new JButton("Keluar");
		btnKeluar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Keluar();
			}
		});
		btnKeluar.setForeground(Color.WHITE);
		btnKeluar.setBackground(new Color(0, 102, 255));
		btnKeluar.setBounds(443, 402, 96, 25);
		contentPane.add(btnKeluar);

		lblNamaKerusakan = new JLabel("Nama Kerusakan :");
		lblNamaKerusakan.setBounds(267, 128, 146, 15);
		contentPane.add(lblNamaKerusakan);

		txtNmKerusakan = new JTextField();
		txtNmKerusakan.setEnabled(false);
		txtNmKerusakan.setColumns(10);
		txtNmKerusakan.setBounds(403, 128, 134, 19);
		contentPane.add(txtNmKerusakan);

		cmbIdKerusakan = new JComboBox();
		cmbIdKerusakan.setModel(new DefaultComboBoxModel(new String[] {"--Pilih--"}));
		cmbIdKerusakan.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String nmkerusakan = "";
					//Connection konek = (Connection) Koneksi.getKoneksi();			
					Class.forName("com.mysql.jdbc.Driver").newInstance();
					Connection konek=DriverManager.getConnection("jdbc:mysql://localhost/sispakonyx",
					"root","root");
					//Connection konek=DriverManager.getConnection("jdbc:mysql://192.168.1.123/sistempakar",
						//	"root","root");
					Statement state = konek.createStatement();
					String sql = "select NmKerusakan from Kerusakan where IdKerusakan = '"
							+ cmbIdKerusakan.getSelectedItem() + "'";
					ResultSet rs = state.executeQuery(sql);
					while (rs.next()) {
						nmkerusakan = rs.getString("NmKerusakan");
					}
					txtNmKerusakan.setText(nmkerusakan);
					rs.close();
					konek.close();
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null,
							"data tidak teridentifikasi", "Pesan",
							JOptionPane.INFORMATION_MESSAGE);
				}
			}
		});
		cmbIdKerusakan.setBackground(Color.WHITE);
		cmbIdKerusakan.setBounds(135, 123, 126, 22);
		contentPane.add(cmbIdKerusakan);

		lblIdTarget = new JLabel("Id Target :");
		lblIdTarget.setBounds(24, 95, 96, 15);
		contentPane.add(lblIdTarget);

		txtIdTarget = new JTextField();
		txtIdTarget.setEnabled(false);
		txtIdTarget.setColumns(10);
		txtIdTarget.setBounds(137, 94, 134, 19);
		contentPane.add(txtIdTarget);

		lblIdGejala = new JLabel("Id Gejala :");
		lblIdGejala.setBounds(26, 158, 126, 15);
		contentPane.add(lblIdGejala);

		cmbIdGejala = new JComboBox();
		cmbIdGejala.setModel(new DefaultComboBoxModel(new String[] {"--Pilih--"}));
		cmbIdGejala.setBounds(137, 151, 126, 22);
		contentPane.add(cmbIdGejala);
		cmbIdGejala.setBackground(Color.WHITE);

		lblNmGejala = new JLabel("Nama Gejala :");
		lblNmGejala.setBounds(269, 154, 126, 15);
		contentPane.add(lblNmGejala);

		txtNmGejala = new JTextField();
		txtNmGejala.setBounds(405, 148, 134, 25);
		contentPane.add(txtNmGejala);
		txtNmGejala.setEnabled(false);
		txtNmGejala.setColumns(10);

		btnUbah = new JButton("Ubah");
		btnUbah.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Connection konek = (Connection) Koneksi.getKoneksi();
					String query = "UPDATE Target SET IdKerusakan  = ?, IdGejala  = ? WHERE IdTarget = ? ";
					PreparedStatement prepare = (PreparedStatement) konek
							.prepareStatement(query);
					prepare.setString(1,
							(String) cmbIdKerusakan.getSelectedItem());
					prepare.setString(2, (String) cmbIdGejala.getSelectedItem());
					prepare.setString(3, txtIdTarget.getText());
					prepare.executeUpdate();
					JOptionPane.showMessageDialog(null, "Data berhasil diubah",
							"Pesan", JOptionPane.INFORMATION_MESSAGE);
					prepare.close();
					tampilTabel();
					btnTambah.setEnabled(true);
					btnKeluar.setEnabled(true);
					btnUbah.setEnabled(false);
					btnHapus.setEnabled(false);
					autoNomer("Target", "TG", JFrame.EXIT_ON_CLOSE);
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, "Data gagal diubah",
							"Pesan", JOptionPane.ERROR_MESSAGE);
					System.out.println(ex);
				}
			}
		});
		btnUbah.setForeground(Color.WHITE);
		btnUbah.setBackground(new Color(0, 102, 255));
		btnUbah.setEnabled(false);
		btnUbah.setBounds(118, 402, 96, 25);
		contentPane.add(btnUbah);

		btnHapus = new JButton("Hapus");
		btnHapus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Connection konek = (Connection) Koneksi.getKoneksi();
					String query = "DELETE FROM Target WHERE IdTarget = ?";
					PreparedStatement prepare = (PreparedStatement) konek
							.prepareStatement(query);

					prepare.setString(1, txtIdTarget.getText());
					prepare.executeUpdate();
					JOptionPane.showMessageDialog(null,
							"Data berhasil dihapus", "Pesan",
							JOptionPane.INFORMATION_MESSAGE);
					prepare.close();
					tampilTabel();
					clean();
					btnTambah.setEnabled(true);
					btnKeluar.setEnabled(true);
					btnUbah.setEnabled(false);
					btnHapus.setEnabled(false);
					autoNomer("Target", "TG", JFrame.EXIT_ON_CLOSE);
				} catch (Exception ex) {
					System.out.println(ex);
					JOptionPane.showMessageDialog(null, "Data gagal diupdate",
							"Pesan", JOptionPane.INFORMATION_MESSAGE);
				}
			}
		});
		btnHapus.setForeground(Color.WHITE);
		btnHapus.setBackground(new Color(0, 102, 255));
		btnHapus.setEnabled(false);
		btnHapus.setBounds(214, 402, 96, 25);
		contentPane.add(btnHapus);
		
		btnCari = new JButton("");
		btnCari.setIcon(new ImageIcon(FrmTarget.class.getResource("/image/system-search.png")));
		btnCari.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cariTarget();
			}
		});
		btnCari.setForeground(Color.WHITE);
		btnCari.setBackground(Color.BLACK);
		btnCari.setBounds(445, 362, 27, 23);
		contentPane.add(btnCari);
		
		txtCari = new JTextField();
		txtCari.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cariTarget();
			}
		});
		txtCari.setColumns(10);
		txtCari.setBounds(149, 365, 289, 19);
		contentPane.add(txtCari);
		
		lblArahan = new JLabel("Cari Target :");
		lblArahan.setBounds(24, 365, 126, 15);
		contentPane.add(lblArahan);
		panel_1.setBackground(new Color(0, 0, 0));
		panel_1.setBounds(0, 57, 558, 10);
		contentPane.add(panel_1);
		cmbIdGejala.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String nmgejala = "";
					//Connection konek = (Connection) Koneksi.getKoneksi();
					Class.forName("com.mysql.jdbc.Driver").newInstance();
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost/sispakonyx",
					"root","root");
					//Connection con=DriverManager.getConnection("jdbc:mysql://192.168.1.123/sistempakar",
						//	"root","root");
					Statement state = con.createStatement();
					String sql = "select NmGejala from Gejala where IdGejala = '"
							+ cmbIdGejala.getSelectedItem() + "'";
					ResultSet rs = state.executeQuery(sql);
					while (rs.next()) {
						nmgejala = rs.getString("NmGejala");
					}
					txtNmGejala.setText(nmgejala);
					rs.close();
					con.close();
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null,
							"data tidak teridentifikasi", "Pesan",
							JOptionPane.INFORMATION_MESSAGE);
				}
			}
		});
		setLocationRelativeTo(null);

		tampilTabel();
		cariIDGejala();
		cariIDKerusakan();
		autoNomer("Target", "TG", JFrame.EXIT_ON_CLOSE);
		// autonumber();
	}

	void cariTarget(){
		try{
			/*Class.forName("com.mysql.jdbc.Driver").newInstance();	
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/sistempakar", "root", "root");*/
			Connection con = (Connection) Koneksi.getKoneksi();
			Statement state = con.createStatement();
			String sql = "select * from Target where IdTarget like '%" + txtCari.getText()+ "%'";
			ResultSet rs = state.executeQuery(sql);
			while (rs.next()) {
			tabelModel.addRow(new Object[]{
			rs.getString(1),
			rs.getString(2),
			rs.getString(3)
			});
			}
			table.setModel(tabelModel);
			//tampilTabel();
			txtCari.setText("");
			}catch (Exception e){
				System.out.println(e);
			}
			}
	
	void cariIDGejala() {
		try {

			//Connection konek = (Connection) Koneksi.getKoneksi();	
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/sispakonyx",
			"root","root");
			//Connection con=DriverManager.getConnection("jdbc:mysql://192.168.1.123/sistempakar",
				//	"root","root");
			Statement st = con.createStatement();
			String sql = "select * from Gejala";
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				cmbIdGejala.addItem(rs.getString(1));
			}
			st.close();
			con.close();
		} catch (Exception ex) {
			System.out.println("tak terdeteksi");
		}
	}

	void cariIDKerusakan() {
		try {
			String nmgejala = "";			
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			//Connection con=DriverManager.getConnection("jdbc:mysql://192.168.1.123/sistempakar",
				//	"root","root");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/sispakonyx",
			"root","root");
			//Connection konek = (Connection) Koneksi.getKoneksi();
			Statement st = con.createStatement();
			String sql = "select * from Kerusakan";
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				cmbIdKerusakan.addItem(rs.getString(1));
			}
			st.close();
			con.close();
		} catch (Exception ex) {
			System.out.println("tak terdeteksi");
		}
	}

	public String autoNomer(String tabel, String strAwal, Integer pnj) {
		String auto = "";
		String s, s1;
		Integer j;
		try {
			//Connection konek = (Connection) Koneksi.getKoneksi();			
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/sispakonyx",
			"root","root");
			//Connection con=DriverManager.getConnection("jdbc:mysql://192.168.1.123/sistempakar",
				//	"root","root");
			java.sql.Statement stat = con.createStatement();
			ResultSet rs = stat.executeQuery("select * from " + tabel);
			rs.last();

			s = Integer.toString(rs.getRow() + 1);
			j = s.length();
			s1 = "";
			for (int i = 1; i <= pnj - j; i++) {
				s1 = s1 + "0";
			}
			rs.close();
			stat.close();
			auto = strAwal + s1 + s;
			txtIdTarget.setText(auto);
		} catch (Exception e) {
			System.out.println("Pesan Error : " + e);
			JOptionPane.showMessageDialog(null,
					"Maaf, Query tidak bisa dijalankan...!!!!");
		}
		return auto;
	}

	public void tampilTabel() {
		try {
			hapusIsiTabel();
			Connection konek = (Connection) Koneksi.getKoneksi();
			Statement state = konek.createStatement();
			String query = "SELECT * FROM Target";
			ResultSet rs = state.executeQuery(query);
			while (rs.next()) {

				Object obj[] = new Object[3];
				obj[0] = rs.getString(1);
				obj[1] = rs.getString(2);
				obj[2] = rs.getString(3);
				tabelModel.addRow(obj);
				sesuaikanKolom();
			}
			rs.close();
			state.close();
		} catch (Exception ex) {
			System.out.println(ex);
		}
	}

	void sesuaikanKolom() {
		// cara untuk menyesuaikan kolom dari tabel adalah mengambil
		// lebar kolom yang ada kemudian sesuaikan
		TableColumnModel modelKolom = table.getColumnModel();

		for (int kol = 0; kol < modelKolom.getColumnCount(); kol++) {
			int lebarKolomMax = 0;
			for (int baris = 0; baris < table.getRowCount(); baris++) {
				TableCellRenderer rend = table.getCellRenderer(baris, kol);
				Object nilaiTablel = table.getValueAt(baris, kol);
				Component comp = rend.getTableCellRendererComponent(table,
						nilaiTablel, false, false, baris, kol);
				lebarKolomMax = Math.max(comp.getPreferredSize().width,
						lebarKolomMax);
			}// akhir for baris
			TableColumn kolom = modelKolom.getColumn(kol);
			kolom.setPreferredWidth(lebarKolomMax);
		}// akhir for kolom
	}

	public void hapusIsiTabel() {
		int a = table.getRowCount();
		int brs;

		for (brs = 0; brs < a; brs++) {
			tabelModel.removeRow(0);

		}
	}

	void Keluar() {
		try {
			int reply = JOptionPane.showConfirmDialog(this,
					"Yakin Mau Keluar?", "Sistem - Keluar",
					JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
			if (reply == JOptionPane.YES_OPTION) {
				setVisible(false); // Menyembunyikan Frame.
				dispose(); // Membersihkan Resource dari system memori
				setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Membebaskan
																// aplikasi dari
																// memori
				// System.exit (0); //Keluar dari Aplikasi.
			}
		} catch (Exception ex) {
		}
	}

	void clean() {
		cmbIdGejala.setSelectedIndex(0);
		cmbIdKerusakan.setSelectedIndex(0);
	}
}
