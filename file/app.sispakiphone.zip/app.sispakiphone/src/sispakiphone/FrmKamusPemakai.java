/*
 =========================================================
 * Nama program : 
 * Keterangan	: Memuat Kamus Pengguna
 * Nama Fie		: FrmKamusPemakai.java
 ========================================================
 */
package sispakiphone;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Color;

import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.Toolkit;

public class FrmKamusPemakai extends JFrame {

	private JPanel contentPane;
	private JTextField txtCari;
	private JButton btnCari;
	private JScrollPane scrollPane;
	private JTextArea textArea;
	private JButton btnCariLagi;
	private JLabel lblDeskripsi;
	private JLabel lblCariBerdasarkan;
	private JButton btnTutup;

	/**
	 * Launch the application.
	 */
	/*
	 public static void main(String[] args) { EventQueue.invokeLater(new
	 Runnable() { public void run() { try { FrmKamusPengguna frame = new
	 FrmKamusPengguna(); frame.setVisible(true); } catch (Exception e) {
	 e.printStackTrace(); } } }); }
	*/

	/**
	 * Create the frame.
	 */
	public FrmKamusPemakai() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(FrmKamusPemakai.class.getResource("/image/konversation.png")));
		setResizable(false);
		setTitle("Kamus");
		// setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 327);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 102, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setLocationRelativeTo(null);

		lblCariBerdasarkan = new JLabel("Cari istilah asing :");
		lblCariBerdasarkan.setForeground(new Color(255, 255, 255));
		lblCariBerdasarkan.setBounds(12, 43, 223, 15);
		contentPane.add(lblCariBerdasarkan);

		txtCari = new JTextField();
		txtCari.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				cari();
			}
		});
		txtCari.setBounds(12, 70, 380, 23);
		contentPane.add(txtCari);
		txtCari.setColumns(10);

		btnCari = new JButton("...");
		btnCari.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cari();
			}
		});
		btnCari.setForeground(Color.WHITE);
		btnCari.setBackground(Color.BLACK);
		btnCari.setBounds(400, 70, 36, 25);
		contentPane.add(btnCari);

		scrollPane = new JScrollPane();
		scrollPane.setBounds(12, 122, 424, 124);
		contentPane.add(scrollPane);

		textArea = new JTextArea();
		textArea.setEditable(false);
		scrollPane.setViewportView(textArea);

		btnCariLagi = new JButton("Cari Lagi");
		btnCariLagi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtCari.setText("");
				textArea.setText("");
				txtCari.requestFocus();
				btnCariLagi.setEnabled(false);
			}
		});
		btnCariLagi.setForeground(Color.WHITE);
		btnCariLagi.setBackground(Color.BLACK);
		btnCariLagi.setEnabled(false);
		btnCariLagi.setBounds(96, 258, 130, 25);
		contentPane.add(btnCariLagi);

		JPanel panel = new JPanel();
		panel.setBackground(Color.BLACK);
		panel.setBounds(0, -13, 448, 23);
		contentPane.add(panel);

		lblDeskripsi = new JLabel("Deskripsi :");
		lblDeskripsi.setForeground(new Color(255, 255, 255));
		lblDeskripsi.setBounds(12, 95, 121, 25);
		contentPane.add(lblDeskripsi);
		
		btnTutup = new JButton("Tutup");
		btnTutup.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
		btnTutup.setForeground(Color.WHITE);
		btnTutup.setBackground(Color.BLACK);
		btnTutup.setBounds(221, 258, 130, 25);
		contentPane.add(btnTutup);
	}

	void cari() {
		try {
			Connection con = (Connection) Koneksi.getKoneksi();
			Statement state = con.createStatement();
			String sql = "select kata,keterangan from Kamus where kata like '%"+ txtCari.getText() + "%'";
			ResultSet rs = state.executeQuery(sql);
			if (rs.next() == true) {
				textArea.setText(rs.getString("keterangan"));
				btnCariLagi.setEnabled(true);
			} else {
				JOptionPane.showMessageDialog(null, "Kata yang anda cari tidak ditemukan",
						"Pesan", JOptionPane.ERROR_MESSAGE);
				txtCari.setText("");
				textArea.setText("");
			}
			rs.close();
			state.close();
		}

		catch (Exception e) {
			System.out.println(e);
		}
	}
}
