/*
 * Nama program : 
 * Keterangan	: Memuat menu utama program
 * Nama Fie		: Homescreen.java
 */

package sispakiphone;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JRadioButton;
import javax.swing.border.LineBorder;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import net.java.balloontip.BalloonTip;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.DriverManager;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.Toolkit;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.SwingConstants;

public class Homescreen extends JFrame {

	private JPanel contentPane;
	private JLabel label;
	private JPanel panel;
	private JTextField txtUsername;
	private JPasswordField pwdPassword;
	private JRadioButton radioButtonPemakai;
	private JRadioButton radioButtonPakar;
	private JLabel lblUsername;
	private JLabel lblPassword;
	private JButton btnLogin;
	private JPanel panelPakar;
	private JLabel lblNmCV;
	private SimpleDateFormat sdf = new SimpleDateFormat("EEEEE,dd MMMMM yyyy");
	private String waktu = sdf.format(new java.util.Date());
	private JButton btnTutup;
	private JLabel lblLabel;
	private BalloonTip tooltip;
	private JPanel panel_2;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Homescreen frame = new Homescreen();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Homescreen() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(Homescreen.class.getResource("/image/konversation.png")));
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowOpened(WindowEvent e) {
				panelPakar.setVisible(false);
				
			}
		});
		setTitle("Selamat Datang");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 554, 431);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setLocationRelativeTo(null);
		setContentPane(contentPane);
		contentPane.setLayout(null);

		panel = new JPanel();
		panel.setBackground(Color.BLACK);
		panel.setBounds(0, -11, 580, 112);
		contentPane.add(panel);
		panel.setLayout(null);

		label = new JLabel("");
		label.setIcon(new ImageIcon(Homescreen.class.getResource("/image/logo2.png")));
		label.setBounds(12, 12, 90, 88);
		panel.add(label);

		JLabel lblSelamatDatangDi = new JLabel("Selamat Datang di");
		lblSelamatDatangDi.setForeground(Color.WHITE);
		lblSelamatDatangDi.setFont(new Font("DejaVu Sans Condensed", Font.BOLD,
				10));
		lblSelamatDatangDi.setBounds(129, 12, 295, 32);
		panel.add(lblSelamatDatangDi);

		JLabel lblsistemPakarDiagnosa = new JLabel(
				"Sistem Pakar Diagnosa untuk Mengidentifikasi \n\n");
		lblsistemPakarDiagnosa.setForeground(Color.WHITE);
		lblsistemPakarDiagnosa.setFont(new Font("DejaVu Sans Condensed",
				Font.BOLD, 15));
		lblsistemPakarDiagnosa.setBounds(129, 31, 449, 32);
		panel.add(lblsistemPakarDiagnosa);
		
		lblNmCV = new JLabel("Kerusakan IPhone 5 dengan");
		lblNmCV.setForeground(Color.WHITE);
		lblNmCV.setFont(new Font("DejaVu Sans Condensed", Font.BOLD, 15));
		lblNmCV.setBounds(129, 56, 449, 18);
		panel.add(lblNmCV);
		
		JLabel lblDenganMetodeBackward = new JLabel("Metode Backward Chaining berbasis Client-Server");
		lblDenganMetodeBackward.setForeground(Color.WHITE);
		lblDenganMetodeBackward.setFont(new Font("DejaVu Sans Condensed", Font.BOLD, 15));
		lblDenganMetodeBackward.setBounds(129, 75, 459, 18);
		panel.add(lblDenganMetodeBackward);

		JLabel label_1 = new JLabel("Silahkan masuk sebagai :");
		label_1.setForeground(new Color(255, 255, 255));
		label_1.setBounds(175, 132, 199, 15);
		contentPane.add(label_1);

		radioButtonPemakai = new JRadioButton("Pemakai");
		radioButtonPemakai.setForeground(new Color(255, 255, 255));
		radioButtonPemakai.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				tooltip = new BalloonTip(radioButtonPemakai, "Anda akan masuk sebagai pemakai");
			}
			@Override
			public void focusLost(FocusEvent e) {
				tooltip.closeBalloon();
			}
		});
		radioButtonPemakai.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				panelPakar.setVisible(false);
				radioButtonPemakai.setEnabled(false);
				FrmMenuPemakai pengguna = new FrmMenuPemakai();
				pengguna.show();
				dispose();
			}
		});
		radioButtonPemakai.setBackground(new Color(0, 102, 255));
		radioButtonPemakai.setBounds(136, 160, 120, 23);
		contentPane.add(radioButtonPemakai);

		radioButtonPakar = new JRadioButton("Pakar");
		radioButtonPakar.setForeground(new Color(255, 255, 255));
		radioButtonPakar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panelPakar.setVisible(true);
				txtUsername.requestFocus();
			}
		});
		radioButtonPakar.setBackground(new Color(0, 102, 255));
		radioButtonPakar.setBounds(260, 160, 149, 23);
		contentPane.add(radioButtonPakar);

		panelPakar = new JPanel();
		panelPakar.setLayout(null);
		panelPakar.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		panelPakar.setBackground(new Color(0, 102, 255));
		panelPakar.setBounds(53, 202, 405, 106);
		contentPane.add(panelPakar);

		lblUsername = new JLabel("Username :");
		lblUsername.setForeground(new Color(255, 255, 255));
		lblUsername.setBounds(12, 25, 118, 15);
		panelPakar.add(lblUsername);

		lblPassword = new JLabel("Password :");
		lblPassword.setForeground(new Color(255, 255, 255));
		lblPassword.setBounds(12, 52, 118, 15);
		panelPakar.add(lblPassword);

		txtUsername = new JTextField();
		//txtUsername.setDocument(new Setvalidator(8, true));
		txtUsername.setColumns(10);
		txtUsername.setBounds(112, 23, 114, 19);
		panelPakar.add(txtUsername);

		btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				login();
			}
		});
		btnLogin.setForeground(Color.WHITE);
		btnLogin.setBackground(new Color(0, 0, 0));
		btnLogin.setBounds(238, 23, 84, 44);
		panelPakar.add(btnLogin);

		pwdPassword = new JPasswordField();
		//pwdPassword.setDocument(new Setvalidator(8, true));
		pwdPassword.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				login();
			}
		});
		pwdPassword.setBounds(112, 52, 114, 19);
		panelPakar.add(pwdPassword);
		
		btnTutup = new JButton("Tutup");
		btnTutup.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
		btnTutup.setForeground(Color.WHITE);
		btnTutup.setBackground(new Color(0, 0, 0));
		btnTutup.setBounds(240, 330, 84, 21);
		contentPane.add(btnTutup);
		
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBackground(Color.BLACK);
		panel_1.setBounds(0, 376, 580, 23);
		contentPane.add(panel_1);
		
		lblLabel = new JLabel("1411530163 - Ghalagghar Zakario Zalfano");
		lblLabel.setHorizontalTextPosition(SwingConstants.LEADING);
		lblLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblLabel.setForeground(Color.WHITE);
		lblLabel.setFont(new Font("DejaVu Sans Condensed", Font.BOLD, 10));
		lblLabel.setBounds(0, 0, 568, 23);
		panel_1.add(lblLabel);
		
		panel_2 = new JPanel();
		panel_2.setBounds(0, 107, 580, 267);
		contentPane.add(panel_2);
		panel_2.setBackground(new Color(0, 102, 255));
	}
	
	void login(){
		try {
			Connection konek = (Connection) Koneksi.getKoneksi();
			String query = "INSERT INTO user VALUES(?,?)";
			Statement state = (Statement) konek.createStatement();
			ResultSet res = (ResultSet) state
					.executeQuery("Select * from User where Username='"
							+ txtUsername.getText() + "'");
			if (res.next()) {
				if (pwdPassword.getText().equals(
						res.getString("Password"))) {
					JOptionPane.showMessageDialog(rootPane,
							"Login berhasil");
					new FrmMenuPakar().show();
					dispose();
				} else {
					getToolkit().beep();
					JOptionPane.showMessageDialog(rootPane,
							"Password Anda Salah");
					pwdPassword.setText("");
					pwdPassword.requestFocus();
				}
			} else {
				getToolkit().beep();
				JOptionPane.showMessageDialog(rootPane,
						"Username Anda Salah");
				txtUsername.setText("");
				pwdPassword.setText("");
				txtUsername.requestFocus();
			}

		}

		catch (Exception ex) {
			// JOptionPane.showMessageDialog(null,"Data gagal disimpan","Pesan",JOptionPane.ERROR_MESSAGE);
			System.out.println(ex);

		}
	}
	
}
