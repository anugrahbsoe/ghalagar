/*
 * Nama program : 
 * Keterangan	: Memuat menu bantuan
 * Nama Fie		: FrmBantuan.java
 */

package sispakiphone;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;

import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.DefaultComboBoxModel;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import java.awt.Toolkit;

public class FrmBantuan extends JFrame {

	private JPanel contentPane;
	private JPanel panel;
	private JLabel lblBantuan;
	private JPanel panel_1;
	private final JPanel panel_2 = new JPanel();
	private JPanel panel_3;

	/**
	 * Launch the application.
	 */
	/*
	 * public static void main(String[] args) { EventQueue.invokeLater(new
	 * Runnable() { public void run() { try { FrmBantuan frame = new
	 * FrmBantuan(); frame.setVisible(true); } catch (Exception e) {
	 * e.printStackTrace(); } } }); }
	 */

	/**
	 * Create the frame.
	 */
	public FrmBantuan() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(FrmBantuan.class.getResource("/image/konversation.png")));
		setResizable(false);
		// setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 398);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setLocationRelativeTo(null);
		setContentPane(contentPane);
		contentPane.setLayout(null);

		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(0, 102, 255));
		panel.setBounds(0, 0, 448, 48);
		contentPane.add(panel);

		lblBantuan = new JLabel("Bantuan");
		lblBantuan.setForeground(Color.WHITE);
		lblBantuan.setFont(new Font("DejaVu Sans Condensed", Font.BOLD, 15));
		lblBantuan.setBounds(188, 12, 64, 24);
		panel.add(lblBantuan);

		panel_1 = new JPanel();
		panel_1.setBackground(new Color(255, 255, 255));
		panel_1.setBounds(12, 71, 424, 246);
		contentPane.add(panel_1);
		panel_1.setLayout(null);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(12, 12, 400, 233);
		panel_1.add(scrollPane);

		JTextArea txtrUntukMelakukan = new JTextArea();
		txtrUntukMelakukan.setLineWrap(true);
		txtrUntukMelakukan.setEditable(false);
		txtrUntukMelakukan
				.setText("Pemakai :\n1. Menu Diagnosa : berfungsi untuk melakukan diagnosa kerusakan\n2. Menu Kamus : berfungsi untuk mencari kata asing\n3. Menu Bantuan : berfungsi sebagai menu petunjuk pengoperasian program \n\nPakar :\n1. Menu Diagnosa : berfungsi untuk melakukan diagnosa kerusakan\n2. Menu Pengetahuan : berfungsi untuk melakukan penambahan,pengubahan menurut gejala,kerusakan dan aturan yang berlaku\n3. Menu Kamus : berfungsi untuk mencari kata asing\n4. Menu Bantuan : berfungsi sebagai menu petunjuk pengoperasian program \n5. Menu Logout : berfungsi untuk keluar dari program pada Menu Pakar");
		scrollPane.setViewportView(txtrUntukMelakukan);

		JButton btnTutup = new JButton("Tutup");
		btnTutup.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
		btnTutup.setForeground(Color.WHITE);
		btnTutup.setBackground(new Color(0, 102, 255));
		btnTutup.setBounds(165, 319, 96, 25);
		contentPane.add(btnTutup);
		panel_2.setBackground(new Color(0, 0, 0));
		panel_2.setBounds(0, 49, 448, 10);
		contentPane.add(panel_2);
		
		panel_3 = new JPanel();
		panel_3.setBackground(Color.BLACK);
		panel_3.setBounds(0, 356, 448, 10);
		contentPane.add(panel_3);

	}

	
}
