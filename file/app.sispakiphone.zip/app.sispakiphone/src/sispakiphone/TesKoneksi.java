package sispakiphone;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;


public class TesKoneksi extends JFrame {

	private JPanel contentPane;
	private JTextField txtHost;
	private JTextField txtUser;
	private JPasswordField txtPass;
	private JButton btnTes;
	private JLabel lblPass;
	private JLabel lblUser;
	private JLabel lblHost;
	private JLabel lblKet;
	private JLabel Message;
	private JButton btnClear;
	private JTextField txtDatabase;
	private JLabel lblDatabase;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TesKoneksi frame = new TesKoneksi();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TesKoneksi() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 505, 333);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblHost = new JLabel("Host :");
		lblHost.setBounds(37, 64, 104, 15);
		contentPane.add(lblHost);
		//txtHost.setText("jdbc:mysql://localhost:3306/");
		
		txtHost = new JTextField();
		txtHost.setColumns(10);
		txtHost.setBounds(142, 64, 243, 19);
		contentPane.add(txtHost);
		
		lblUser = new JLabel("Username :");
		lblUser.setBounds(37, 124, 104, 15);
		contentPane.add(lblUser);
		
		txtUser = new JTextField();
		txtUser.setColumns(10);
		txtUser.setBounds(142, 122, 142, 19);
		contentPane.add(txtUser);
		
		lblPass = new JLabel("Password :");
		lblPass.setBounds(37, 151, 104, 15);
		contentPane.add(lblPass);
		
		txtPass = new JPasswordField();
		txtPass.setBounds(142, 149, 142, 19);
		contentPane.add(txtPass);
		
		btnTes = new JButton("Tes Koneksi");
		btnTes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//String db = txtHost.getText();
		        //String host = "jdbc:mysql://localhost:3306/"+db;
				String db = txtHost.getText();
				String host = "jdbc:mysql://localhost/"+db;
				String user = txtUser.getText();
		        String pass = txtPass.getText();
		        String driver = "com.mysql.jdbc.Driver";
		         
		        try {
		            Class.forName(driver).newInstance();
		            Connection con = null;
		            con = DriverManager.getConnection(host, user, pass);
		            lblKet.setText("Koneksi Berhasil");
		        } catch (Exception e) {
		            lblKet.setText(e.getMessage());
		        }
			}
		});
		btnTes.setForeground(Color.WHITE);
		btnTes.setBackground(Color.BLACK);
		btnTes.setBounds(141, 180, 155, 25);
		contentPane.add(btnTes);
		
		lblKet = new JLabel("");
		lblKet.setBounds(142, 224, 349, 19);
		contentPane.add(lblKet);
		
		Message = new JLabel("*Message :");
		Message.setBounds(37, 224, 104, 15);
		contentPane.add(Message);
		
		btnClear = new JButton("Clear\n");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				txtHost.setText("");
				txtDatabase.setText("");
				txtUser.setText("");
				txtPass.setText("");
				lblKet.setText("");
			}
		});
		btnClear.setForeground(Color.WHITE);
		btnClear.setBackground(Color.BLACK);
		btnClear.setBounds(305, 180, 155, 25);
		contentPane.add(btnClear);
		
		lblDatabase = new JLabel("Database :");
		lblDatabase.setBounds(37, 95, 104, 15);
		contentPane.add(lblDatabase);
		
		txtDatabase = new JTextField();
		txtDatabase.setColumns(10);
		txtDatabase.setBounds(142, 93, 142, 19);
		contentPane.add(txtDatabase);
	}
}
