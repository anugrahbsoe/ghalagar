/*
 ======================================================================= 
 * Nama program : 
 * Keterangan	: Memuat Basis Aturan
 * Nama Fie		: FrmBasisAturan.java
 ======================================================================= 
 */
package sispakiphone;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import IconMakeOver.IconLabel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Toolkit;

public class FrmBasisAturan extends JFrame {

	private JPanel contentPane;
	private IconLabel cnlblIdentifikasi;
	private IconLabel cnlblAturanYa;
	private IconLabel cnlblAturanTidak;
	private JLabel lblBack;
	private JPanel panel;
	private JLabel lblBasisAturan;
	private JLabel label;

	/**
	 * Launch the application.
	 */
	
	 /*public static void main(String[] args) { EventQueue.invokeLater(new
	 Runnable() { public void run() { try { FrmBasisAturan frame = new
	 FrmBasisAturan(); frame.setVisible(true); } catch (Exception e) {
	 e.printStackTrace(); } } }); }*/
	

	/**
	 * Create the frame.
	 */
	public FrmBasisAturan() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(FrmBasisAturan.class.getResource("/image/konversation.png")));
		setResizable(false);
		setTitle("Basis Aturan");
		// setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 501, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 102, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		cnlblIdentifikasi = new IconLabel();
		cnlblIdentifikasi.setForeground(Color.WHITE);
		cnlblIdentifikasi.setIconReflect(new ImageIcon(FrmBasisAturan.class.getResource("/image/preferences-system.png")));
		cnlblIdentifikasi.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				FrmTarget frame = new FrmTarget();
				frame.show();
			}
		});
		cnlblIdentifikasi.setHorizontalAlignment(SwingConstants.CENTER);
		cnlblIdentifikasi.setIcon(new ImageIcon(FrmBasisAturan.class.getResource("/image/preferences-system.png")));
		cnlblIdentifikasi.setText("Target");
		cnlblIdentifikasi.setBounds(26, 54, 139, 143);
		contentPane.add(cnlblIdentifikasi);

		cnlblAturanYa = new IconLabel();
		cnlblAturanYa.setForeground(Color.WHITE);
		cnlblAturanYa.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				FrmAturanYa frame = new FrmAturanYa();
				frame.show();
			}
		});
		cnlblAturanYa.setIcon(new ImageIcon(FrmBasisAturan.class.getResource("/image/preferences-system.png")));
		cnlblAturanYa.setText("Aturan Ya");
		cnlblAturanYa.setHorizontalAlignment(SwingConstants.CENTER);
		cnlblAturanYa.setBounds(175, 54, 139, 143);
		contentPane.add(cnlblAturanYa);

		cnlblAturanTidak = new IconLabel();
		cnlblAturanTidak.setForeground(Color.WHITE);
		cnlblAturanTidak.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				FrmAturanTidak frame = new FrmAturanTidak();
				frame.show();
			}
		});
		cnlblAturanTidak.setIcon(new ImageIcon(FrmBasisAturan.class.getResource("/image/preferences-system.png")));
		cnlblAturanTidak.setText("Aturan Tidak");
		cnlblAturanTidak.setHorizontalAlignment(SwingConstants.CENTER);
		cnlblAturanTidak.setBounds(326, 54, 139, 143);
		contentPane.add(cnlblAturanTidak);

		lblBack = new JLabel("");
		lblBack.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
			}
		});
		lblBack.setHorizontalAlignment(SwingConstants.CENTER);
		lblBack.setHorizontalTextPosition(SwingConstants.CENTER);
		lblBack.setIcon(new ImageIcon(FrmBasisAturan.class.getResource("/image/converseen.png")));
		lblBack.setBounds(217, 209, 55, 34);
		contentPane.add(lblBack);
		
		panel = new JPanel();
		panel.setBounds(0, 51, 499, 4);
		contentPane.add(panel);
		
		lblBasisAturan = new JLabel("-- Basis Aturan --");
		lblBasisAturan.setForeground(Color.WHITE);
		lblBasisAturan.setBounds(184, 12, 154, 30);
		contentPane.add(lblBasisAturan);
		
		label = new JLabel("");
		label.setIcon(new ImageIcon(FrmBasisAturan.class.getResource("/image/unity-tweak-tool.png")));
		label.setForeground(Color.WHITE);
		label.setBounds(0, 0, 154, 42);
		contentPane.add(label);
		setLocationRelativeTo(null);
	}
}
