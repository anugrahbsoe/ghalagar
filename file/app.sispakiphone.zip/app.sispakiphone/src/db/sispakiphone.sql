-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 19, 2015 at 04:29 PM
-- Server version: 5.5.35-1
-- PHP Version: 5.5.9-1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sispakiphone`
--

-- --------------------------------------------------------

--
-- Table structure for table `Gejala`
--

CREATE TABLE IF NOT EXISTS `Gejala` (
  `IdGejala` varchar(4) NOT NULL,
  `NmGejala` varchar(150) NOT NULL,
  PRIMARY KEY (`IdGejala`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Gejala`
--

INSERT INTO `Gejala` (`IdGejala`, `NmGejala`) VALUES
('A010', 'IPhone dapat dinyalakan'),
('A020', 'IPhone tidak dapat dinyalakan'),
('B010', 'Pernah tertekan'),
('B020', 'Masa pakai sudah lama'),
('B030', 'Pernah terkena air'),
('B040', 'Pernah terjatuh'),
('B050', 'Kamera tidak dapat dibuka'),
('B060', 'Memory terpasang dengan baik'),
('B070', 'Sering mengalami hang'),
('B080', 'Tidak ada getar'),
('B090', 'Lampu LED tidak menyala'),
('C010', 'Lampu LED Menyala Merah'),
('C020', 'Muncul tanda silang'),
('C030', 'Baterai dalam kondisi baik'),
('C040', 'Sulit ditekan'),
('C050', 'Home Button macet'),
('C060', 'Volume normal'),
('C070', 'Muncul pesan insert simcard'),
('C080', 'Sinyal tidak stabil'),
('C090', 'Muncul pesan close another application'),
('C100', 'Memory tidak terbaca'),
('C110', 'Akselerasi lambat'),
('C120', 'Panas berlebihan'),
('C130', 'Settingan pada posisi getar aktif'),
('C140', 'Tidak ada tegangan'),
('D010', 'Layar LCD Blank Putih'),
('D020', 'Terdapat bintik biru keunguan'),
('D030', 'Baterai habis total'),
('D040', 'Indikator isi ulang tidak berjalan'),
('D050', 'Konektor Keypad dalam kondisi baik'),
('D060', 'Home Button lost'),
('D070', 'Suara tidak terdengar lawan bicara'),
('D080', 'Suara lawan bicara tidak terdengar'),
('D090', 'Suara terdengar kecil'),
('D100', 'Fisik simcard berubah'),
('D110', 'Jauh dari pemancar'),
('D120', 'Tidak ada aplikasi yang aktif'),
('D130', 'Soket memory dalam kondisi baik'),
('D140', 'Terlalu banyak aplikasi yang diinstall'),
('D150', 'Muncul icon loading'),
('D160', 'Vibrator tidak terjepit chasing'),
('D170', 'Dicharger terlalu lama'),
('E010', 'Dapat menerima panggilan'),
('E020', 'Berjalan normal setelah lepas baterai'),
('E030', 'Membentuk pola seperti danau'),
('E040', 'Tegangan baterai sesuai standar'),
('E050', 'Tegangan baterai kurang dari 3,5v'),
('E060', 'Tipe baterai tidak sesuai'),
('E070', 'Kabel Charger dalam kondisi baik'),
('E080', 'Charger dalam kondisi baik'),
('E090', 'Lapisan keypad sudah aus'),
('E100', 'Terjadi korosi'),
('E110', 'keypad double typing'),
('E120', 'Tidak bisa digerakkan'),
('E130', 'Susah digeser'),
('E140', 'Suara mic dalam kondisi baik'),
('E150', 'Suara musik tidak terdengar'),
('E160', 'Speaker berdebu'),
('E170', 'Konektor simcard dalam kondisi baik'),
('E180', 'Simcard dalam kondisi baik'),
('E190', 'Tidak dapat melakukan panggilan'),
('E200', 'IC Signal dalam kondisi baik'),
('E210', 'Hanya dapat digunakan pada salah satu operator'),
('E220', 'IC Driver dalam kondisi baik'),
('E230', 'Slot memory eksternal dalam kondisi baik'),
('E240', 'Space memory minim'),
('E250', 'Aplikasi konflik'),
('E260', 'Restart otomatis'),
('E270', 'Baterai berkurang drastis'),
('E280', 'Jalur IC UI dalam kondisi baik'),
('E290', 'Vibrator berfungsi dengan baik'),
('E300', 'Baterai asli'),
('E310', 'tidak teridentifikasi'),
('E320', 'akhir ');

-- --------------------------------------------------------

--
-- Table structure for table `Kamus`
--

CREATE TABLE IF NOT EXISTS `Kamus` (
  `KdKamus` varchar(5) NOT NULL,
  `Kata` varchar(50) NOT NULL,
  `Keterangan` varchar(250) NOT NULL,
  PRIMARY KEY (`KdKamus`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Kamus`
--

INSERT INTO `Kamus` (`KdKamus`, `Kata`, `Keterangan`) VALUES
('KM001', 'Memory Drain', 'Memory Drain atau Memory Habis adalah sebuah situasi dimana \r\nblackberry kehilangan daya karena terlalu banyak\r\naplikasi yang diinstall'),
('KM002', 'Leak', 'LCD yg bocor (leak) biasanya adalah adanya bintik2 biru atau keunguan seperti terkena coretan pena/bolpoi'),
('KM003', 'Keypad double typing', 'Adalah situasi dimana hasil pengetikan\nmenghasilkan angka atau huruf yang \nberulang / ganda ');

-- --------------------------------------------------------

--
-- Table structure for table `Kerusakan`
--

CREATE TABLE IF NOT EXISTS `Kerusakan` (
  `IdKerusakan` varchar(4) NOT NULL,
  `NmKerusakan` varchar(250) NOT NULL,
  `Solusi` varchar(1000) NOT NULL,
  PRIMARY KEY (`IdKerusakan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Kerusakan`
--

INSERT INTO `Kerusakan` (`IdKerusakan`, `NmKerusakan`, `Solusi`) VALUES
('K010', 'LCD Rusak', 'Ganti LCD'),
('K020', 'LCD Hang', 'Install Ulang OS'),
('K030', 'LCD Leak', 'Ganti LCD'),
('K040', 'Baterai Rusak', 'Ganti Baterai'),
('K050', 'Daya baterai habis', 'Kejutkan baterai'),
('K060', 'IC Power Rusak	', 'Ganti IC Power'),
('K070', 'Charge Rusak', 'Ganti Charge'),
('K080', 'IC Charge Rusak', 'Ganti IC Charge'),
('K090', 'Touchscreen rusak', 'Ganti Touchscreen'),
('K100', 'Touchscreen kotor', 'Bersihkan touchscreen'),
('K110', 'Keytone Rusak		', 'Ganti Keytone'),
('K120', 'Home Button Rusak', 'Ganti Home Button'),
('K130', 'Home Button Kotor', 'Bersihkan Home Button'),
('K140', 'Mic Rusak', 'Ganti Mic'),
('K150', 'Speaker Rusak', 'Ganti speaker'),
('K160', 'Speaker Kotor', 'Bersihkan speaker'),
('K170', 'Simcard Rusak', 'Ganti simcard'),
('K180', 'Slot simcard rusak', 'Ganti slot simcard'),
('K190', 'No Signal', 'Solder ulang konektor Antena'),
('K200', 'IC SWIT Antena Rusak', 'Ganti IC SWIT Antena'),
('K210', 'IC PA Rusak', 'Ganti IC PA'),
('K220', 'Kamera Rusak', 'Ganti Kamera'),
('K230', 'Memory card Rusak', 'Ganti Memory card'),
('K240', 'Memory Drain', 'Clear Log'),
('K250', 'Salah install aplikasi', 'Hapus aplikasi yang terakhir diinstall'),
('K260', 'OS Rusak', 'Upgrade OS'),
('K270', 'Mengalami overheat', 'Lepaskan baterai'),
('K280', 'Vibrator Rusak', 'Ganti Vibrator'),
('K290', 'IC UI Rusak', 'Ganti IC UI'),
('K300', 'Mengalami korsleting', 'Ganti komponen yang korsleting');

-- --------------------------------------------------------

--
-- Table structure for table `Punya_Aturan_Tidak`
--

CREATE TABLE IF NOT EXISTS `Punya_Aturan_Tidak` (
  `IdAturanTidak` varchar(4) NOT NULL,
  `Satu` varchar(4) NOT NULL,
  `Dua` varchar(4) NOT NULL,
  PRIMARY KEY (`IdAturanTidak`),
  KEY `id_kesimpulan` (`Satu`),
  KEY `id_identifikasi` (`Dua`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Punya_Aturan_Tidak`
--

INSERT INTO `Punya_Aturan_Tidak` (`IdAturanTidak`, `Satu`, `Dua`) VALUES
('T001', 'E010', 'E020'),
('T002', 'E020', 'E030'),
('T003', 'E030', 'E310'),
('T004', 'E040', 'E050'),
('T005', 'E050', 'E060'),
('T006', 'E060', 'E310'),
('T007', 'E070', 'E080'),
('T008', 'E080', 'E310'),
('T009', 'E090', 'E100'),
('T010', 'E100', 'E110'),
('T011', 'E110', 'E310'),
('T012', 'E120', 'E130'),
('T013', 'E130', 'E310'),
('T014', 'E140', 'E310'),
('T015', 'E150', 'E310'),
('T016', 'E160', 'E310'),
('T017', 'E170', 'E180'),
('T018', 'E180', 'E310'),
('T019', 'E190', 'E200'),
('T020', 'E200', 'E210'),
('T021', 'E210', 'E310'),
('T022', 'E220', 'E310'),
('T023', 'E230', 'E310'),
('T024', 'E240', 'E310'),
('T025', 'E250', 'E260'),
('T026', 'E260', 'E270'),
('T027', 'E270', 'E310'),
('T028', 'E280', 'E290'),
('T029', 'E290', 'E310'),
('T030', 'E300', 'E310'),
('T031', 'D010', 'D020'),
('T032', 'D020', 'E320'),
('T033', 'DO30', 'E320'),
('T034', 'D040', 'E320'),
('T035', 'D050', 'E320'),
('T036', 'D060', 'E320'),
('T037', 'D070', 'D080'),
('T038', 'D080', 'D090'),
('T039', 'D090', 'E320'),
('T040', 'D100', 'E320'),
('T041', 'D110', 'E320'),
('T042', 'D120', 'E320'),
('T043', 'D130', 'E320'),
('T044', 'D140', 'E320'),
('T045', 'D150', 'E320'),
('T046', 'D160', 'E320'),
('T047', 'D170', 'E320'),
('T048', 'C010', 'E320'),
('T049', 'C020', 'E320'),
('T050', 'C030', 'C040'),
('T051', 'C040', 'C050'),
('T052', 'C050', 'E320'),
('T053', 'C060', 'C070'),
('T054', 'C070', 'C080'),
('T055', 'C080', 'E320'),
('T056', 'C090', 'E320'),
('T057', 'C100', 'E320'),
('T058', 'C110', 'C120'),
('T059', 'C120', 'E320'),
('T060', 'C130', 'E320'),
('T061', 'C140', 'E320'),
('T062', 'B010', 'B020'),
('T063', 'B020', 'B030'),
('T064', 'B030', 'B040'),
('T065', 'B040', 'B050'),
('T066', 'B050', 'B060'),
('T067', 'B060', 'B070'),
('T068', 'B070', 'B080'),
('T069', 'B080', 'E320'),
('T070', 'B090', 'E320'),
('T071', 'A010', 'E320'),
('T072', 'A020', 'E320');

-- --------------------------------------------------------

--
-- Table structure for table `Punya_Aturan_Ya`
--

CREATE TABLE IF NOT EXISTS `Punya_Aturan_Ya` (
  `IdAturanYa` varchar(4) NOT NULL,
  `Satu` varchar(4) NOT NULL,
  `Dua` varchar(4) NOT NULL,
  PRIMARY KEY (`IdAturanYa`),
  KEY `id_kesimpulan` (`Satu`),
  KEY `id_identifikasi` (`Dua`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Punya_Aturan_Ya`
--

INSERT INTO `Punya_Aturan_Ya` (`IdAturanYa`, `Satu`, `Dua`) VALUES
('Y001', 'E010', 'D010'),
('Y002', 'D010', 'C010'),
('Y003', 'C010', 'B010'),
('Y004', 'B010', 'A010'),
('Y005', 'E020', 'D010'),
('Y006', 'E030', 'D020'),
('Y007', 'D020', 'C010'),
('Y008', 'E040', 'D030'),
('Y009', 'D030', 'C020'),
('Y010', 'C020', 'B020'),
('Y011', 'B020', 'A010'),
('Y012', 'E050', 'D030'),
('Y013', 'E060', 'D030'),
('Y014', 'E070', 'D040'),
('Y015', 'D040', 'C030'),
('Y016', 'C030', 'B030'),
('Y017', 'B030', 'A010'),
('Y018', 'E080', 'D040'),
('Y019', 'E090', 'D050'),
('Y020', 'D050', 'C040'),
('Y021', 'C040', 'B030'),
('Y022', 'E100', 'D050'),
('Y023', 'E110', 'D050'),
('Y024', 'E120', 'D060'),
('Y025', 'D060', 'C050'),
('Y026', 'C050', 'B030'),
('Y027', 'E130', 'D060'),
('Y028', 'E140', 'D070'),
('Y029', 'D070', 'C060'),
('Y030', 'C060', 'B040'),
('Y031', 'B040', 'A010'),
('Y032', 'E150', 'D080'),
('Y033', 'D080', 'C060'),
('Y034', 'E160', 'D090'),
('Y035', 'D090', 'C060'),
('Y036', 'E170', 'D100'),
('Y037', 'D100', 'C070'),
('Y038', 'C070', 'B040'),
('Y039', 'E180', 'D100'),
('Y040', 'E190', 'D110'),
('Y041', 'D110', 'C080'),
('Y042', 'C080', 'B040'),
('Y043', 'E200', 'D110'),
('Y044', 'E210', 'D110'),
('Y045', 'E220', 'D120'),
('Y046', 'D120', 'C090'),
('Y047', 'C090', 'B050'),
('Y048', 'B050', 'A010'),
('Y049', 'E230', 'D130'),
('Y050', 'D130', 'C100'),
('Y051', 'C100', 'B060'),
('Y052', 'B060', 'A010'),
('Y053', 'E240', 'D140'),
('Y054', 'D140', 'C110'),
('Y055', 'C110', 'B070'),
('Y056', 'B070', 'A010'),
('Y057', 'E250', 'D150'),
('Y058', 'D150', 'C120'),
('Y059', 'C120', 'B070'),
('Y060', 'E260', 'D150'),
('Y061', 'E270', 'D150'),
('Y062', 'E280', 'D160'),
('Y063', 'D160', 'C130'),
('Y064', 'C130', 'B080'),
('Y065', 'B080', 'A010'),
('Y066', 'E290', 'D160'),
('Y067', 'E300', 'D170'),
('Y068', 'D170', 'C140'),
('Y069', 'C140', 'B090'),
('Y070', 'B090', 'A020');

-- --------------------------------------------------------

--
-- Table structure for table `Target`
--

CREATE TABLE IF NOT EXISTS `Target` (
  `IdTarget` varchar(5) NOT NULL,
  `IdKerusakan` varchar(4) NOT NULL,
  `IdGejala` varchar(4) NOT NULL,
  PRIMARY KEY (`IdTarget`),
  KEY `id_identifikasi` (`IdGejala`),
  KEY `id_kesimpulan` (`IdKerusakan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Target`
--

INSERT INTO `Target` (`IdTarget`, `IdKerusakan`, `IdGejala`) VALUES
('TG001', 'K010', 'A010'),
('TG002', 'K010', 'B010'),
('TG003', 'K010', 'C010'),
('TG004', 'K010', 'D010'),
('TG005', 'K010', 'E010'),
('TG006', 'K020', 'A010'),
('TG007', 'K020', 'B010'),
('TG008', 'K020', 'C010'),
('TG009', 'K020', 'D010'),
('TG010', 'K020', 'E020'),
('TG011', 'K030', 'A010'),
('TG012', 'K030', 'B010'),
('TG013', 'K030', 'C010'),
('TG014', 'K030', 'D020'),
('TG015', 'K030', 'E030'),
('TG016', 'K040', 'A010'),
('TG017', 'K040', 'B020'),
('TG018', 'K040', 'C020'),
('TG019', 'K040', 'D030'),
('TG020', 'K040', 'E040'),
('TG021', 'K050', 'A010'),
('TG022', 'K050', 'B020'),
('TG023', 'K050', 'C020'),
('TG024', 'K050', 'D030'),
('TG025', 'K050', 'E050'),
('TG026', 'K060', 'A010'),
('TG027', 'K060', 'B020'),
('TG028', 'K060', 'C020'),
('TG029', 'K060', 'D030'),
('TG030', 'K060', 'E060'),
('TG031', 'K070', 'A010'),
('TG032', 'K070', 'B030'),
('TG033', 'K070', 'C030'),
('TG034', 'K070', 'D040'),
('TG035', 'K070', 'E070'),
('TG036', 'K080', 'A010'),
('TG037', 'K080', 'B030'),
('TG038', 'K080', 'C030'),
('TG039', 'K080', 'D040'),
('TG040', 'K080', 'E080'),
('TG041', 'K090', 'A010'),
('TG042', 'K090', 'B030'),
('TG043', 'K090', 'C040'),
('TG044', 'K090', 'D050'),
('TG045', 'K090', 'E090'),
('TG046', 'K100', 'A010'),
('TG047', 'K100', 'B030'),
('TG048', 'K100', 'C040'),
('TG049', 'K100', 'D050'),
('TG050', 'K100', 'E100'),
('TG051', 'K110', 'A010'),
('TG052', 'K110', 'B030'),
('TG053', 'K110', 'C040'),
('TG054', 'K110', 'D050'),
('TG055', 'K110', 'E110'),
('TG056', 'K120', 'A010'),
('TG057', 'K120', 'B030'),
('TG058', 'K120', 'C050'),
('TG059', 'K120', 'D060'),
('TG060', 'K120', 'E120'),
('TG061', 'K130', 'A010'),
('TG062', 'K130', 'B030'),
('TG063', 'K130', 'C050'),
('TG064', 'K130', 'D060'),
('TG065', 'K130', 'E130'),
('TG066', 'K140', 'A010'),
('TG067', 'K140', 'B040'),
('TG068', 'K140', 'C060'),
('TG069', 'K140', 'D070'),
('TG070', 'K140', 'E140'),
('TG071', 'K150', 'A010'),
('TG072', 'K150', 'B040'),
('TG073', 'K150', 'C060'),
('TG074', 'K150', 'D080'),
('TG075', 'K150', 'E150'),
('TG076', 'K160', 'A010'),
('TG077', 'K160', 'B040'),
('TG078', 'K160', 'C060'),
('TG079', 'K160', 'D090'),
('TG080', 'K160', 'E160'),
('TG081', 'K170', 'A010'),
('TG082', 'K170', 'B040'),
('TG083', 'K170', 'C070'),
('TG084', 'K170', 'D100'),
('TG085', 'K170', 'E170'),
('TG086', 'K180', 'A010'),
('TG087', 'K180', 'B040'),
('TG088', 'K180', 'C070'),
('TG089', 'K180', 'D100'),
('TG090', 'K180', 'E180'),
('TG091', 'K190', 'A010'),
('TG092', 'K190', 'B040'),
('TG093', 'K190', 'C080'),
('TG094', 'K190', 'D110'),
('TG095', 'K190', 'E190'),
('TG096', 'K200', 'A010'),
('TG097', 'K200', 'B040'),
('TG098', 'K200', 'C080'),
('TG099', 'K200', 'D110'),
('TG100', 'K200', 'E200'),
('TG101', 'K210', 'A010'),
('TG102', 'K210', 'B040'),
('TG103', 'K210', 'C080'),
('TG104', 'K210', 'D110'),
('TG105', 'K210', 'E210'),
('TG106', 'K220', 'A010'),
('TG107', 'K220', 'B050'),
('TG108', 'K220', 'C090'),
('TG109', 'K220', 'D120'),
('TG110', 'K220', 'E220'),
('TG111', 'K230', 'A010'),
('TG112', 'K230', 'B060'),
('TG113', 'K230', 'C100'),
('TG114', 'K230', 'D130'),
('TG115', 'K230', 'E230'),
('TG116', 'K240', 'A010'),
('TG117', 'K240', 'B070'),
('TG118', 'K240', 'C110'),
('TG119', 'K240', 'D140'),
('TG120', 'K240', 'E240'),
('TG121', 'K250', 'A010'),
('TG122', 'K250', 'B070'),
('TG123', 'K250', 'C120'),
('TG124', 'K250', 'D150'),
('TG125', 'K250', 'E250'),
('TG126', 'K260', 'A010'),
('TG127', 'K260', 'B070'),
('TG128', 'K260', 'C120'),
('TG129', 'K260', 'D150'),
('TG130', 'K260', 'E260'),
('TG131', 'K270', 'A010'),
('TG132', 'K270', 'B070'),
('TG133', 'K270', 'C120'),
('TG134', 'K270', 'D150'),
('TG135', 'K270', 'E270'),
('TG136', 'K280', 'A010'),
('TG137', 'K280', 'B080'),
('TG138', 'K280', 'C130'),
('TG139', 'K280', 'D160'),
('TG140', 'K280', 'E280'),
('TG141', 'K290', 'A010'),
('TG142', 'K290', 'B080'),
('TG143', 'K290', 'C130'),
('TG144', 'K290', 'D160'),
('TG145', 'K290', 'E290'),
('TG146', 'K300', 'A020'),
('TG147', 'K300', 'B090'),
('TG148', 'K300', 'C140'),
('TG149', 'K300', 'D170'),
('TG150', 'K300', 'E300');

-- --------------------------------------------------------

--
-- Table structure for table `Temp`
--

CREATE TABLE IF NOT EXISTS `Temp` (
  `IdGejala` varchar(4) NOT NULL,
  `NmGejala` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `User`
--

CREATE TABLE IF NOT EXISTS `User` (
  `Id` int(2) NOT NULL AUTO_INCREMENT,
  `Username` varchar(8) NOT NULL,
  `Password` varchar(8) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `User`
--

INSERT INTO `User` (`Id`, `Username`, `Password`) VALUES
(1, 'pakar', 'pakar');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Target`
--
ALTER TABLE `Target`
  ADD CONSTRAINT `Target_ibfk_1` FOREIGN KEY (`IdKerusakan`) REFERENCES `Kerusakan` (`IdKerusakan`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `Target_ibfk_2` FOREIGN KEY (`IdGejala`) REFERENCES `Gejala` (`IdGejala`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
